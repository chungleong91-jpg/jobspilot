import { useEffect } from 'react'

export default function Privacy() {
  useEffect(() => {
    document.title = 'Privacy Policy | JobsPilot Singapore'
  }, [])

  return (
    <section className="legal-page">
      <div className="container legal-container">
        <span className="eyebrow eyebrow-static">
          <span className="eyebrow-dot"></span>
          Legal
        </span>
        <h1>Privacy Policy</h1>
        <p className="legal-updated">Last updated: 28 August 2026</p>

        <div className="legal-body">
          <p>
            JobsPilot ("we", "us", "our") operates this website to connect jobseekers
            in Singapore with verified employers. This Privacy Policy explains how we
            collect, use and protect your personal data in accordance with Singapore's
            Personal Data Protection Act (PDPA).
          </p>

          <h2>1. Information We Collect</h2>
          <p>When you submit an application through JobsPilot, we collect:</p>
          <ul>
            <li>Full name</li>
            <li>Phone number and WhatsApp number</li>
            <li>Age and gender</li>
            <li>Current occupation</li>
          </ul>
          <p>
            We may also automatically collect limited technical information such as
            browser type and general usage data to improve the performance of our website.
          </p>

          <h2>2. How We Use Your Information</h2>
          <ul>
            <li>To match you with relevant job opportunities</li>
            <li>To contact you by phone or WhatsApp regarding your application</li>
            <li>To share your profile with prospective employers on our platform</li>
            <li>To improve our services and candidate matching process</li>
          </ul>

          <h2>3. Sharing of Information</h2>
          <p>
            We share your application details only with employers actively hiring for
            roles that match your profile. We do not sell your personal data to third
            parties for marketing purposes.
          </p>

          <h2>4. Data Storage and Security</h2>
          <p>
            Application data is stored securely using industry-standard infrastructure.
            Access is restricted to authorised JobsPilot staff involved in the
            recruitment process.
          </p>

          <h2>5. Your Rights</h2>
          <p>
            Under the PDPA, you may request access to, correction of, or withdrawal of
            consent for the use of your personal data at any time by contacting us at{' '}
            <a href="mailto:hello@jobspilot.sg">hello@jobspilot.sg</a>.
          </p>

          <h2>6. Data Retention</h2>
          <p>
            We retain your application data only for as long as necessary to fulfil the
            purposes outlined in this policy, or as required by law.
          </p>

          <h2>7. Changes to This Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. Changes will be posted
            on this page with a revised "last updated" date.
          </p>

          <h2>8. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at{' '}
            <a href="mailto:hello@jobspilot.sg">hello@jobspilot.sg</a>.
          </p>
        </div>
      </div>
    </section>
  )
}
