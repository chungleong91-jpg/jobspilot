import { useEffect } from 'react'

export default function Terms() {
  useEffect(() => {
    document.title = 'Terms of Service | JobsPilot Singapore'
  }, [])

  return (
    <section className="legal-page">
      <div className="container legal-container">
        <span className="eyebrow eyebrow-static">
          <span className="eyebrow-dot"></span>
          Legal
        </span>
        <h1>Terms of Service</h1>
        <p className="legal-updated">Last updated: 28 August 2026</p>

        <div className="legal-body">
          <p>
            These Terms of Service ("Terms") govern your use of the JobsPilot website
            and application services. By using this website, you agree to these Terms.
          </p>

          <h2>1. About JobsPilot</h2>
          <p>
            JobsPilot is a recruitment platform that connects jobseekers with verified
            employers across Singapore. We facilitate introductions between candidates
            and employers but are not the direct employer for most listed roles.
          </p>

          <h2>2. Eligibility</h2>
          <p>
            You must provide accurate and truthful information when submitting an
            application. JobsPilot reserves the right to reject or remove applications
            that contain false or misleading information.
          </p>

          <h2>3. No Application Fees</h2>
          <p>
            JobsPilot never charges jobseekers to apply, interview, or accept a job
            offer. If anyone claiming to represent JobsPilot requests payment from you,
            please report it to <a href="mailto:hello@jobspilot.sg">hello@jobspilot.sg</a> immediately.
          </p>

          <h2>4. Use of the Platform</h2>
          <p>You agree not to:</p>
          <ul>
            <li>Submit false, misleading or fraudulent information</li>
            <li>Use the platform for any unlawful purpose</li>
            <li>Attempt to disrupt or interfere with the operation of the website</li>
          </ul>

          <h2>5. Employer Listings</h2>
          <p>
            While we take reasonable steps to verify employers before listing roles,
            JobsPilot does not guarantee employment outcomes and is not responsible for
            the conduct of third-party employers after an introduction is made.
          </p>

          <h2>6. Limitation of Liability</h2>
          <p>
            JobsPilot provides this platform on an "as is" basis and makes no
            guarantee of job placement. To the fullest extent permitted by law, we are
            not liable for any indirect or consequential loss arising from your use of
            this website.
          </p>

          <h2>7. Changes to These Terms</h2>
          <p>
            We may revise these Terms from time to time. Continued use of the website
            after changes are posted constitutes acceptance of the updated Terms.
          </p>

          <h2>8. Governing Law</h2>
          <p>
            These Terms are governed by the laws of the Republic of Singapore.
          </p>

          <h2>9. Contact Us</h2>
          <p>
            For questions about these Terms, contact us at{' '}
            <a href="mailto:hello@jobspilot.sg">hello@jobspilot.sg</a>.
          </p>
        </div>
      </div>
    </section>
  )
}
