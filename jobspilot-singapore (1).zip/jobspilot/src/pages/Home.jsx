import Hero from '../components/Hero.jsx'
import Stats from '../components/Stats.jsx'
import FeaturedJobs from '../components/FeaturedJobs.jsx'
import WhyChoose from '../components/WhyChoose.jsx'
import ApplySection from '../components/ApplySection.jsx'
import FAQ from '../components/FAQ.jsx'

export default function Home() {
  return (
    <>
      <Hero />
      <Stats />
      <FeaturedJobs />
      <WhyChoose />
      <ApplySection />
      <FAQ />
    </>
  )
}
