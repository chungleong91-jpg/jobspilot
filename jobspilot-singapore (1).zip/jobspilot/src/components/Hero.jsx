export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-glow" aria-hidden="true"></div>
      <div className="container hero-grid">
        <div className="hero-copy">
          <span className="eyebrow">
            <span className="eyebrow-dot"></span>
            Singapore's fastest-growing job platform
          </span>
          <h1>Find Better Jobs in Singapore</h1>
          <p className="hero-sub">
            Discover verified full-time, part-time and remote opportunities with
            competitive salaries from trusted Singapore employers.
          </p>
          <div className="hero-actions">
            <a href="#apply" className="btn btn-primary btn-lg">Apply Now</a>
            <a href="#jobs" className="btn btn-outline btn-lg">View Jobs</a>
          </div>
          <div className="hero-trust">
            <div className="avatar-stack" aria-hidden="true">
              <span></span><span></span><span></span><span></span>
            </div>
            <p><strong>12,000+</strong> candidates placed this year</p>
          </div>
        </div>

        <div className="hero-art" aria-hidden="true">
          <div className="hero-art-blob"></div>

          <div className="job-card float-card card-1">
            <div className="job-card-top">
              <div className="job-card-logo logo-blue">CS</div>
              <div>
                <p className="job-card-title">Customer Service Exec</p>
                <p className="job-card-loc">Raffles Place · Full Time</p>
              </div>
            </div>
            <div className="job-card-salary">
              <span>SGD 2,800 – 3,500 / mo</span>
              <span className="badge-verified">✓ Verified</span>
            </div>
          </div>

          <div className="job-card float-card card-2">
            <div className="job-card-top">
              <div className="job-card-logo logo-navy">LC</div>
              <div>
                <p className="job-card-title">Logistics Coordinator</p>
                <p className="job-card-loc">Jurong · Full Time</p>
              </div>
            </div>
            <div className="job-card-salary">
              <span>SGD 3,200 – 4,200 / mo</span>
              <span className="badge-verified">✓ Verified</span>
            </div>
          </div>

          <div className="job-card float-card card-3">
            <div className="job-card-top">
              <div className="job-card-logo logo-sky">RC</div>
              <div>
                <p className="job-card-title">Remote Chat Support</p>
                <p className="job-card-loc">Work from Home</p>
              </div>
            </div>
            <div className="job-card-salary">
              <span>SGD 2,600 – 3,300 / mo</span>
              <span className="badge-verified">✓ Verified</span>
            </div>
          </div>

          <div className="stat-pill pill-1">
            <span className="stat-pill-num">96%</span>
            <span className="stat-pill-label">Placement rate</span>
          </div>
        </div>
      </div>
    </section>
  )
}
