const JOBS = [
  {
    title: 'Customer Service Executive',
    company: 'Marina Bay Contact Centre',
    location: 'Raffles Place, Singapore',
    type: 'Full Time',
    salary: 'SGD 2,800 – 3,500 / mo',
    initials: 'MB',
    tone: 'logo-blue',
  },
  {
    title: 'Administrative Assistant',
    company: 'Orchard Business Solutions',
    location: 'Orchard, Singapore',
    type: 'Full Time',
    salary: 'SGD 2,600 – 3,200 / mo',
    initials: 'OB',
    tone: 'logo-navy',
  },
  {
    title: 'Warehouse Assistant',
    company: 'Jurong Logistics Hub',
    location: 'Jurong West, Singapore',
    type: 'Full Time',
    salary: 'SGD 2,400 – 2,900 / mo',
    initials: 'JL',
    tone: 'logo-sky',
  },
  {
    title: 'Retail Sales Associate',
    company: 'Tampines Retail Group',
    location: 'Tampines, Singapore',
    type: 'Part Time',
    salary: 'SGD 1,800 – 2,400 / mo',
    initials: 'TR',
    tone: 'logo-blue',
  },
  {
    title: 'Remote Chat Support',
    company: 'Sentosa Digital Services',
    location: 'Work from Home',
    type: 'Full Time',
    salary: 'SGD 2,600 – 3,300 / mo',
    initials: 'SD',
    tone: 'logo-navy',
  },
  {
    title: 'Logistics Coordinator',
    company: 'Woodlands Freight Pte Ltd',
    location: 'Woodlands, Singapore',
    type: 'Full Time',
    salary: 'SGD 3,200 – 4,200 / mo',
    initials: 'WF',
    tone: 'logo-sky',
  },
]

export default function FeaturedJobs() {
  return (
    <section className="jobs-section" id="jobs">
      <div className="container">
        <div className="section-head">
          <span className="eyebrow eyebrow-static">
            <span className="eyebrow-dot"></span>
            Featured Roles
          </span>
          <h2>Openings hiring right now</h2>
          <p>A snapshot of verified roles from employers actively hiring across Singapore this week.</p>
        </div>

        <div className="jobs-grid">
          {JOBS.map((job) => (
            <article className="job-tile" key={job.title}>
              <div className="job-tile-top">
                <div className={`job-card-logo ${job.tone}`}>{job.initials}</div>
                <span className={`type-chip ${job.type === 'Full Time' ? 'chip-full' : 'chip-part'}`}>
                  {job.type}
                </span>
              </div>
              <h3>{job.title}</h3>
              <p className="job-tile-company">{job.company}</p>
              <p className="job-tile-loc">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M12 21s7-6.6 7-12a7 7 0 10-14 0c0 5.4 7 12 7 12z" stroke="currentColor" strokeWidth="1.7" />
                  <circle cx="12" cy="9" r="2.4" stroke="currentColor" strokeWidth="1.7" />
                </svg>
                {job.location}
              </p>
              <div className="job-tile-footer">
                <span className="job-tile-salary">{job.salary}</span>
                <a href="#apply" className="btn btn-primary btn-sm">Apply</a>
              </div>
            </article>
          ))}
        </div>

        <div className="jobs-cta">
          <a href="#apply" className="btn btn-outline btn-lg">View All Jobs</a>
        </div>
      </div>
    </section>
  )
}
