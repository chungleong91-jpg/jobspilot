const REASONS = [
  {
    title: 'Verified Employers',
    desc: 'Every company on JobsPilot is vetted by our team before a listing goes live, so you only apply to real, trusted employers.',
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
        <path d="M12 3l7 3v5c0 4.6-3 8.4-7 10-4-1.6-7-5.4-7-10V6l7-3z" stroke="#2563EB" strokeWidth="1.7" strokeLinejoin="round" />
        <path d="M9 12l2 2 4-4" stroke="#2563EB" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    title: 'Fast Application Process',
    desc: 'One short form gets your profile to hiring employers, most candidates hear back within 48 hours of applying.',
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
        <path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" stroke="#2563EB" strokeWidth="1.7" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    title: 'No Application Fees',
    desc: 'JobsPilot is completely free for jobseekers. You will never be asked to pay to apply, interview or get hired.',
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="9" stroke="#2563EB" strokeWidth="1.7" />
        <path d="M8.5 8.5l7 7M15.5 8.5l-7 7" stroke="#2563EB" strokeWidth="1.7" strokeLinecap="round" />
      </svg>
    ),
  },
]

export default function WhyChoose() {
  return (
    <section className="why-section" id="why-us">
      <div className="container">
        <div className="section-head">
          <span className="eyebrow eyebrow-static">
            <span className="eyebrow-dot"></span>
            Why JobsPilot
          </span>
          <h2>Built for Singapore jobseekers</h2>
          <p>We remove the guesswork from job hunting with verified listings and a process built around speed and trust.</p>
        </div>

        <div className="why-grid">
          {REASONS.map((r) => (
            <div className="why-card" key={r.title}>
              <div className="why-icon">{r.icon}</div>
              <h3>{r.title}</h3>
              <p>{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
