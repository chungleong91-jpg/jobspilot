const STATS = [
  { value: '8,500+', label: 'Active Jobs' },
  { value: '1,200+', label: 'Singapore Companies' },
  { value: '96%', label: 'Successful Placement' },
  { value: '24/7', label: 'Candidate Support' },
]

export default function Stats() {
  return (
    <section className="stats-section">
      <div className="container stats-grid">
        {STATS.map((s) => (
          <div className="stat-card" key={s.label}>
            <span className="stat-value">{s.value}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>
    </section>
  )
}
