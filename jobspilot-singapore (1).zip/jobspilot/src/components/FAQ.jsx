import { useState } from 'react'

const FAQS = [
  {
    q: 'Can foreigners apply?',
    a: 'Yes. We work with employers who hire both Singapore citizens/PRs and eligible work-pass holders. Eligibility depends on the specific role and your current pass status, which our team will confirm with you.',
  },
  {
    q: 'Do I need experience?',
    a: 'Many of our listings, including retail, warehouse and customer service roles, are open to candidates with little or no prior experience. Job requirements are listed on each posting.',
  },
  {
    q: 'Are remote jobs available?',
    a: 'Yes, we regularly list remote and work-from-home roles such as chat support and virtual assistance alongside on-site positions.',
  },
  {
    q: 'How long does approval take?',
    a: 'Most applications are reviewed within 1–2 business days. Our team will contact you by phone or WhatsApp once your profile has been matched to a role.',
  },
  {
    q: 'Is there any fee?',
    a: 'No. JobsPilot is completely free for jobseekers. We never charge candidates to apply, interview or accept a job offer.',
  },
  {
    q: 'How will I be contacted?',
    a: 'Our recruitment team will reach out using the phone or WhatsApp number you provide in your application, so please make sure your details are accurate.',
  },
]

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0)

  return (
    <section className="faq-section" id="faq">
      <div className="container">
        <div className="section-head">
          <span className="eyebrow eyebrow-static">
            <span className="eyebrow-dot"></span>
            FAQ
          </span>
          <h2>Frequently asked questions</h2>
          <p>Everything you need to know before applying with JobsPilot.</p>
        </div>

        <div className="faq-list">
          {FAQS.map((item, i) => {
            const isOpen = openIndex === i
            return (
              <div className={`faq-item ${isOpen ? 'is-open' : ''}`} key={item.q}>
                <button
                  className="faq-question"
                  onClick={() => setOpenIndex(isOpen ? -1 : i)}
                  aria-expanded={isOpen}
                >
                  {item.q}
                  <span className="faq-icon" aria-hidden="true"></span>
                </button>
                <div className="faq-answer">
                  <p>{item.a}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
