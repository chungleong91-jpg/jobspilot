import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

export default function Header() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const location = useLocation()
  const isHome = location.pathname === '/'

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMenuOpen(false)
  }, [location.pathname])

  const navLink = (hash, label) =>
    isHome ? (
      <a href={hash} onClick={() => setMenuOpen(false)}>{label}</a>
    ) : (
      <Link to={`/${hash}`} onClick={() => setMenuOpen(false)}>{label}</Link>
    )

  return (
    <header className={`site-header ${scrolled ? 'is-scrolled' : ''}`}>
      <div className="container header-row">
        <Link to="/" className="brand" onClick={() => setMenuOpen(false)}>
          <span className="brand-mark" aria-hidden="true">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7l10 5 10-5-10-5z" fill="#fff" />
              <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.85" />
            </svg>
          </span>
          <span className="brand-name">JobsPilot</span>
        </Link>

        <nav className={`main-nav ${menuOpen ? 'is-open' : ''}`}>
          {navLink('#jobs', 'Jobs')}
          {navLink('#why-us', 'Why Us')}
          {navLink('#apply', 'Apply')}
          {navLink('#faq', 'FAQ')}
        </nav>

        <div className="header-cta">
          <a href={isHome ? '#apply' : '/#apply'} className="btn btn-primary btn-sm">Apply Now</a>
        </div>

        <button
          className={`menu-toggle ${menuOpen ? 'is-open' : ''}`}
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
        >
          <span></span><span></span><span></span>
        </button>
      </div>
    </header>
  )
}
