import { useState } from 'react'

const initialState = {
  fullName: '',
  phone: '',
  whatsapp: '',
  age: '',
  gender: '',
  occupation: '',
}

const SG_PHONE_RE = /^(\+65)?[\s-]?[3689]\d{3}[\s-]?\d{4}$/

function validate(values) {
  const errors = {}

  if (!values.fullName.trim() || values.fullName.trim().length < 2) {
    errors.fullName = 'Please enter your full name.'
  }

  if (!values.phone.trim()) {
    errors.phone = 'Phone number is required.'
  } else if (!SG_PHONE_RE.test(values.phone.trim())) {
    errors.phone = 'Enter a valid Singapore phone number.'
  }

  if (!values.whatsapp.trim()) {
    errors.whatsapp = 'WhatsApp number is required.'
  } else if (!SG_PHONE_RE.test(values.whatsapp.trim())) {
    errors.whatsapp = 'Enter a valid WhatsApp number.'
  }

  const ageNum = Number(values.age)
  if (!values.age) {
    errors.age = 'Age is required.'
  } else if (Number.isNaN(ageNum) || ageNum < 16 || ageNum > 75) {
    errors.age = 'Enter an age between 16 and 75.'
  }

  if (!values.gender) {
    errors.gender = 'Please select a gender.'
  }

  if (!values.occupation.trim() || values.occupation.trim().length < 2) {
    errors.occupation = 'Please enter your current occupation.'
  }

  return errors
}

export default function ApplicationForm() {
  const [values, setValues] = useState(initialState)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | loading | success | error
  const [serverError, setServerError] = useState('')

  function handleChange(e) {
    const { name, value } = e.target
    setValues((v) => ({ ...v, [name]: value }))
    setErrors((err) => ({ ...err, [name]: undefined }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    const validationErrors = validate(values)
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) return

    setStatus('loading')
    setServerError('')

    try {
      const res = await fetch('/api/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      })

      const data = await res.json().catch(() => ({}))

      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Something went wrong. Please try again.')
      }

      setStatus('success')
      setValues(initialState)
    } catch (err) {
      setStatus('error')
      setServerError(err.message || 'Something went wrong. Please try again.')
    }
  }

  if (status === 'success') {
    return (
      <div className="form-success">
        <div className="form-success-icon" aria-hidden="true">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
            <path d="M5 13l4 4L19 7" stroke="#16A34A" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h3>Application received!</h3>
        <p>Thanks for applying with JobsPilot. Our team will reach out to you on WhatsApp within 1–2 business days.</p>
        <button className="btn btn-outline" onClick={() => setStatus('idle')}>Submit another application</button>
      </div>
    )
  }

  return (
    <form className="apply-form" onSubmit={handleSubmit} noValidate>
      <div className="form-row">
        <div className="form-field">
          <label htmlFor="fullName">Full Name</label>
          <input
            id="fullName"
            name="fullName"
            type="text"
            placeholder="e.g. Tan Wei Ming"
            value={values.fullName}
            onChange={handleChange}
            aria-invalid={!!errors.fullName}
          />
          {errors.fullName && <span className="field-error">{errors.fullName}</span>}
        </div>

        <div className="form-field">
          <label htmlFor="occupation">Current Occupation</label>
          <input
            id="occupation"
            name="occupation"
            type="text"
            placeholder="e.g. Retail Associate"
            value={values.occupation}
            onChange={handleChange}
            aria-invalid={!!errors.occupation}
          />
          {errors.occupation && <span className="field-error">{errors.occupation}</span>}
        </div>
      </div>

      <div className="form-row">
        <div className="form-field">
          <label htmlFor="phone">Phone Number</label>
          <input
            id="phone"
            name="phone"
            type="tel"
            placeholder="+65 9123 4567"
            value={values.phone}
            onChange={handleChange}
            aria-invalid={!!errors.phone}
          />
          {errors.phone && <span className="field-error">{errors.phone}</span>}
        </div>

        <div className="form-field">
          <label htmlFor="whatsapp">WhatsApp Number</label>
          <input
            id="whatsapp"
            name="whatsapp"
            type="tel"
            placeholder="+65 9123 4567"
            value={values.whatsapp}
            onChange={handleChange}
            aria-invalid={!!errors.whatsapp}
          />
          {errors.whatsapp && <span className="field-error">{errors.whatsapp}</span>}
        </div>
      </div>

      <div className="form-row">
        <div className="form-field">
          <label htmlFor="age">Age</label>
          <input
            id="age"
            name="age"
            type="number"
            min="16"
            max="75"
            placeholder="e.g. 27"
            value={values.age}
            onChange={handleChange}
            aria-invalid={!!errors.age}
          />
          {errors.age && <span className="field-error">{errors.age}</span>}
        </div>

        <div className="form-field">
          <label htmlFor="gender">Gender</label>
          <select
            id="gender"
            name="gender"
            value={values.gender}
            onChange={handleChange}
            aria-invalid={!!errors.gender}
          >
            <option value="">Select gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Prefer not to say">Prefer not to say</option>
          </select>
          {errors.gender && <span className="field-error">{errors.gender}</span>}
        </div>
      </div>

      {status === 'error' && (
        <div className="form-error-banner" role="alert">{serverError}</div>
      )}

      <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={status === 'loading'}>
        {status === 'loading' ? (
          <>
            <span className="spinner" aria-hidden="true"></span>
            Submitting...
          </>
        ) : (
          'Submit Application'
        )}
      </button>

      <p className="form-disclaimer">
        By submitting, you agree to our <a href="/terms-of-service">Terms of Service</a> and{' '}
        <a href="/privacy-policy">Privacy Policy</a>. No application fees, ever.
      </p>
    </form>
  )
}
