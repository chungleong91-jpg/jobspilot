import ApplicationForm from './ApplicationForm.jsx'

export default function ApplySection() {
  return (
    <section className="apply-section" id="apply">
      <div className="container apply-grid">
        <div className="apply-info">
          <span className="eyebrow eyebrow-static">
            <span className="eyebrow-dot"></span>
            Get Started
          </span>
          <h2>Apply in under 2 minutes</h2>
          <p>
            Fill in your details once and our recruitment team will match you with
            suitable openings and reach out directly on WhatsApp.
          </p>
          <ul className="apply-points">
            <li>No resume required to get started</li>
            <li>100% free, no hidden charges</li>
            <li>Response within 1–2 business days</li>
          </ul>
        </div>

        <div className="apply-card">
          <ApplicationForm />
        </div>
      </div>
    </section>
  )
}
