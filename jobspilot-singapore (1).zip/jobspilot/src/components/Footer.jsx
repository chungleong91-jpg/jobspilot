import { Link, useLocation } from 'react-router-dom'

export default function Footer() {
  const location = useLocation()
  const isHome = location.pathname === '/'
  const year = new Date().getFullYear()

  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <span className="brand">
            <span className="brand-mark brand-mark-footer" aria-hidden="true">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7l10 5 10-5-10-5z" fill="#fff" />
                <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.85" />
              </svg>
            </span>
            <span className="brand-name">JobsPilot</span>
          </span>
          <p>Singapore's trusted platform for verified full‑time, part‑time and remote job opportunities.</p>
        </div>

        <div className="footer-col">
          <h4>Company</h4>
          <ul>
            <li>{isHome ? <a href="#why-us">About</a> : <Link to="/#why-us">About</Link>}</li>
            <li>{isHome ? <a href="#jobs">Jobs</a> : <Link to="/#jobs">Jobs</Link>}</li>
            <li>{isHome ? <a href="#faq">FAQ</a> : <Link to="/#faq">FAQ</Link>}</li>
          </ul>
        </div>

        <div className="footer-col">
          <h4>Legal</h4>
          <ul>
            <li><Link to="/privacy-policy">Privacy Policy</Link></li>
            <li><Link to="/terms-of-service">Terms of Service</Link></li>
          </ul>
        </div>

        <div className="footer-col">
          <h4>Contact</h4>
          <ul>
            <li><a href="mailto:hello@jobspilot.sg">hello@jobspilot.sg</a></li>
            <li><a href="tel:+6561234567">+65 6123 4567</a></li>
            <li>Raffles Place, Singapore</li>
          </ul>
        </div>
      </div>

      <div className="container footer-bottom">
        <p>© {year} JobsPilot. All rights reserved.</p>
        <p>Made for jobseekers across Singapore 🇸🇬</p>
      </div>
    </footer>
  )
}
