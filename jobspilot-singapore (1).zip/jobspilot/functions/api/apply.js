// Cloudflare Pages Function: POST /api/apply
// Inserts a job application into the Supabase `job_applications` table.
//
// Required environment variables (set in Cloudflare Pages > Settings > Environment variables):
//   SUPABASE_URL       - e.g. https://xxxxxxxx.supabase.co
//   SUPABASE_ANON_KEY   - Supabase anon/public API key
//
// Expected table schema (job_applications):
//   full_name   text
//   phone       text
//   whatsapp    text
//   age         int4
//   gender      text
//   occupation  text
//   created_at  timestamptz default now()

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...CORS_HEADERS,
    },
  });
}

const SG_PHONE_RE = /^(\+65)?[\s-]?[3689]\d{3}[\s-]?\d{4}$/;

function validatePayload(data) {
  const errors = [];

  const fullName = String(data.fullName || '').trim();
  const phone = String(data.phone || '').trim();
  const whatsapp = String(data.whatsapp || '').trim();
  const age = Number(data.age);
  const gender = String(data.gender || '').trim();
  const occupation = String(data.occupation || '').trim();

  if (fullName.length < 2) errors.push('A valid full name is required.');
  if (!SG_PHONE_RE.test(phone)) errors.push('A valid Singapore phone number is required.');
  if (!SG_PHONE_RE.test(whatsapp)) errors.push('A valid WhatsApp number is required.');
  if (!Number.isFinite(age) || age < 16 || age > 75) errors.push('Age must be between 16 and 75.');
  if (!gender) errors.push('Gender is required.');
  if (occupation.length < 2) errors.push('Current occupation is required.');

  return {
    errors,
    clean: { full_name: fullName, phone, whatsapp, age, gender, occupation },
  };
}

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}

export async function onRequestPost(context) {
  const { request, env } = context;

  let data;
  try {
    data = await request.json();
  } catch {
    return jsonResponse({ success: false, message: 'Invalid request body.' }, 400);
  }

  const { errors, clean } = validatePayload(data);
  if (errors.length > 0) {
    return jsonResponse({ success: false, message: errors[0], errors }, 422);
  }

  const SUPABASE_URL = env.SUPABASE_URL;
  const SUPABASE_ANON_KEY = env.SUPABASE_ANON_KEY;

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    return jsonResponse(
      { success: false, message: 'Server is not configured. Please try again later.' },
      500
    );
  }

  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/job_applications`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        Prefer: 'return=representation',
      },
      body: JSON.stringify([
        {
          full_name: clean.full_name,
          phone: clean.phone,
          whatsapp: clean.whatsapp,
          age: clean.age,
          gender: clean.gender,
          occupation: clean.occupation,
          created_at: new Date().toISOString(),
        },
      ]),
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      console.error('Supabase insert failed:', res.status, errText);
      return jsonResponse(
        { success: false, message: 'Could not save your application. Please try again.' },
        502
      );
    }

    const inserted = await res.json().catch(() => []);

    return jsonResponse({
      success: true,
      message: 'Application submitted successfully.',
      data: Array.isArray(inserted) ? inserted[0] : inserted,
    });
  } catch (err) {
    console.error('Unexpected error submitting application:', err);
    return jsonResponse(
      { success: false, message: 'Unexpected server error. Please try again.' },
      500
    );
  }
}

export async function onRequestGet() {
  return jsonResponse({ success: false, message: 'Method not allowed.' }, 405);
}
